package ceng.ceng351.labdb;


import java.util.ArrayList;

public class LabDB2 {

    ArrayList<Bucket> bucketList = new ArrayList<>();
    public int globalBucketSize = 0;
    public int globalDepth = 1;

    public LabDB2(int bucketSize) {
        Bucket b1= new Bucket(1, bucketSize);
        bucketList.add(b1);
        bucketList.add(new Bucket(1, bucketSize));
        this.globalBucketSize = bucketSize;
    }

    public void enter(String studentID) {
        int hashValue = GetHashValue(studentID);
        Bucket bucket = bucketList.get(hashValue);
        int currentLength = bucket.StudentIds.size();
        boolean check = currentLength == globalBucketSize;
        while (check) 
        {
            if (bucket.LocalDepth == globalDepth) {
                //global split
                globalDepth++;
                ArrayList<Bucket> tempHashList = new ArrayList<Bucket>();
                
                for (Bucket hashPointer : bucketList) {
                    tempHashList.add(hashPointer);
                    tempHashList.add(hashPointer);
                }
                bucketList = tempHashList;
            }
            
            int temp_cond = Power(2,globalDepth-bucket.LocalDepth);
            int temp_startpoint = hashValue*2;
            
            
            Bucket tempBucket2 = null;
            tempBucket2 = bucketList.get(temp_startpoint);
            Bucket tempBucket = new Bucket(tempBucket2.LocalDepth+1,globalBucketSize);
            Bucket tempBucket4 = tempBucket2;
            
            
            for (int i = 0; i < temp_cond; i++) {
                
                tempBucket2 = bucketList.get(temp_startpoint);
                temp_startpoint++;
                
                if (i < temp_cond/2)
                    tempBucket2 = tempBucket;
                else
                    tempBucket2.LocalDepth++;
            }
            
            for (String tempBucketStudentId : tempBucket4.StudentIds) {
               int newHashValue = GetHashValue(tempBucketStudentId);
               Bucket a = bucketList.get(newHashValue);
               a.StudentIds.add(tempBucketStudentId);   
                if (true) {
                    System.out.println("emre");
                }
            }
            
            hashValue = GetHashValue(studentID);
            bucket = bucketList.get(hashValue);
            check = bucket.StudentIds.size() == globalBucketSize;
        }
        hashValue = GetHashValue(studentID);
        bucket = bucketList.get(hashValue);
        bucket.StudentIds.add(studentID);
    }

    public void leave(String studentID) {

    }

    public String search(String studentID) {
        return "";
    }

    public void printLab() {
        int i = 0;
        System.out.println("Global depth : "+globalDepth);
        for (Bucket bucket : bucketList) {
            String result =
                    GetLeftPaddedAndTruncated(globalDepth ,Integer.toString(i, 2)) + " : [Local depth:" 
                    + bucket.LocalDepth+"]";
            for (String StudentId : bucket.StudentIds) {
                result+="<"+StudentId+">";
            }
            System.out.println(result);
        }

    }

    public int GetHashValue(String studentID) {
        
        int studentIdNumber = Integer.parseInt(studentID.substring(1));
        String binaryNumber = Integer.toString(studentIdNumber, 2);
        return Integer.parseInt(Reverse(GetLeftPaddedAndTruncated(globalDepth,binaryNumber)),2);
    }
    private String GetLeftPaddedAndTruncated(int length,String string)
    {
        String result="";
        if(length > string.length()) {
        for(int i =string.length();i<length;i++)
        {
            result += "0";
        }
        result +=string;
        }
        else
        {
            result = string.substring(string.length()-length,string.length());
        }
        
        return result;
    }
    private String Reverse(String param)
    {
        return new StringBuilder(param).reverse().toString();
    }
    
    private int Power(int alt, int ust)
    {
        int result = 1;
        for (int i = 0; i < ust; i++) {
            result = result * alt;
        }
        return result;
    }
}
